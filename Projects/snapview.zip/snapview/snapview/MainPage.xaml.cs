﻿using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;



namespace snapview
{
   
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            this.SizeChanged += (a,b) => {
                ApplicationViewState views = ApplicationView.Value;
                VisualStateManager.GoToState(this, views.ToString(), false);

            };

        }

       
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }
    }
}
